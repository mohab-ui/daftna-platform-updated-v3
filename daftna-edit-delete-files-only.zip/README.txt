Copy these files into the root of your project (overwrite):
- app/courses/[courseId]/page.tsx
- components/ResourceRow.tsx
- app/globals.css
- lib/favorites.ts

Then run:
  npm run dev
